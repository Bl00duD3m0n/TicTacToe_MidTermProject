package com.example.dip701.tictactoe_dkisels

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.core.view.children

//This code was created by Daniels Kisels with a help of ChatGPT and youtube videos

class MainActivity : AppCompatActivity() {
    private lateinit var nameInputLayout: LinearLayout
    private lateinit var nameInputLabelTextView: TextView
    private lateinit var nameInputEditText: EditText
    private lateinit var nameSubmitButton: Button

    private lateinit var greetingMessageLayout: LinearLayout
    private lateinit var greetingMessageTextView: TextView
    private lateinit var gameModeRadioGroup: RadioGroup
    private lateinit var pvpRadioButton: RadioButton
    private lateinit var pvcRadioButton: RadioButton
    private lateinit var startGameButton: Button
    private lateinit var playerName: String
    private lateinit var boardButtons: List<Button>
    private lateinit var resultTextView: TextView

    private var currentPlayer = TicTacToeGame.Player.X
    private var gameState = TicTacToeGame.GameState.IN_PROGRESS

    private val game = TicTacToeGame()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Inflate the name input layout
        nameInputLayout = layoutInflater.inflate(R.layout.greetings, null) as LinearLayout

        // Find the views in the layout
        nameInputLabelTextView = nameInputLayout.findViewById(R.id.nameInputLabelTextView)
        nameInputEditText = nameInputLayout.findViewById(R.id.nameInputEditText)
        nameSubmitButton = nameInputLayout.findViewById(R.id.nameSubmitButton)

        // Set the content view to the name input layout
        setContentView(nameInputLayout)

        // Handle the name submit button click
        nameSubmitButton.setOnClickListener {
            // Move to the greeting message screen
            playerName = nameInputEditText.text.toString()
            greetingMessageTextView.text = "Hello, $playerName! Please select a game mode."
            setContentView(greetingMessageLayout)
        }

        // Inflate the greeting message layout
        greetingMessageLayout =
            layoutInflater.inflate(R.layout.game_mode_choose, null) as LinearLayout

        // Find the views in the layout
        greetingMessageTextView = greetingMessageLayout.findViewById(R.id.greetingMessageTextView)
        gameModeRadioGroup = greetingMessageLayout.findViewById(R.id.gameModeRadioGroup)
        pvpRadioButton = greetingMessageLayout.findViewById(R.id.pvpRadioButton)
        pvcRadioButton = greetingMessageLayout.findViewById(R.id.pvcRadioButton)
        startGameButton = greetingMessageLayout.findViewById(R.id.startGameButton)

        // Handle the start game button click
        startGameButton.setOnClickListener {
            // Move to the game screen
            val gameScreenLayout =
                layoutInflater.inflate(R.layout.game_screen, null) as RelativeLayout

            // Find the views in the layout
            val boardGridLayout = gameScreenLayout.findViewById<GridLayout>(R.id.boardGridLayout)
            boardButtons = boardGridLayout.children.filterIsInstance<Button>().toList()
            resultTextView = gameScreenLayout.findViewById(R.id.resultTextView)

            // Set the content view to the game screen layout
            setContentView(gameScreenLayout)

            // Initialize the game board buttons
            for (i in boardButtons.indices) {
                boardButtons[i].tag = i
            }

            // Set the board button click listener
            boardButtons.forEach { button ->
                button.setOnClickListener {
                    if (gameState == TicTacToeGame.GameState.IN_PROGRESS) {
                        val index = button.tag as Int
                        if (game.placePiece(index, currentPlayer)) {
                            button.text = currentPlayer.toString()
                            gameState = game.getGameState()
                            if (gameState == TicTacToeGame.GameState.IN_PROGRESS) {
                                currentPlayer = currentPlayer.opposite()
                            } else {
                                showResultDialog()
                            }
                        }
                    }
                }
            }
        }
    }
    private fun showResultDialog() {
        val resultMessage = when (gameState) {
            TicTacToeGame.GameState.X_WON -> "$playerName wins!"
            TicTacToeGame.GameState.O_WON -> "$playerName lost!"
            TicTacToeGame.GameState.DRAW -> "It's a draw!"
            else -> throw IllegalStateException("Unexpected game state: $gameState")
        }

        val dialog = AlertDialog.Builder(this)
            .setTitle("Game Over")
            .setMessage(resultMessage)
            .setPositiveButton("Play Again") { _, _ -> resetGame() }
            .setNegativeButton("Quit") { _, _ -> finish() }
            .create()

        dialog.show()
    }
    private fun resetGame() {
        currentPlayer = TicTacToeGame.Player.X
        gameState = TicTacToeGame.GameState.IN_PROGRESS
        game.reset()
        boardButtons.forEach { button -> button.text = "" }
        resultTextView.visibility = View.GONE
    }
}


class TicTacToeGame {
    enum class Player {
        X, O;

        fun opposite(): Player {
            return if (this == X) O else X
        }
    }

    enum class GameState { IN_PROGRESS, X_WON, O_WON, DRAW }

    private var board = arrayOfNulls<Player>(9)

    private var currentPlayer = Player.X

    private var moveCount = 0

    fun placePiece(index: Int, player: Player): Boolean {
        if (board[index] != null) {
            return false
        }
        board[index] = player
        moveCount++
        return true
    }

    fun getGameState(): GameState {
        if (isWinner(Player.X)) {
            return GameState.X_WON
        }
        if (isWinner(Player.O)) {
            return GameState.O_WON
        }
        if (moveCount == 9) {
            return GameState.DRAW
        }
        return GameState.IN_PROGRESS
    }

    fun reset() {
        board = arrayOfNulls<Player>(9)
        currentPlayer = Player.X
        this.moveCount = 0
    }

    private fun isWinner(player: Player): Boolean {
        // Check rows
        for (i in 0..6 step 3) {
            if (board[i] == player && board[i + 1] == player && board[i + 2] == player) {
                return true
            }
        }

        // Check columns
        for (i in 0..2) {
            if (board[i] == player && board[i + 3] == player && board[i + 6] == player) {
                return true
            }
        }

        // Check diagonals
        if (board[0] == player && board[4] == player && board[8] == player) {
            return true
        }
        if (board[2] == player && board[4] == player && board[6] == player) {
            return true
        }

        return false
    }
}